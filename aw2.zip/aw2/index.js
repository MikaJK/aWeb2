const express = require('express')
const app = express()
const port = 3000

app.use(express.json());
app.use(express.static('public'))

var list=[];

app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.post('/list', (req, res) => {
    list.push(req.body.text)
    res.send('list: '+list)
})
  
  

app.get('/echo/:id', (req, res) => {
    res.send('id:' + req.params.id)
  })

  app.post('/sum', (req, res) => {
    console.log(req.body.numbers)
    var sum=0;
    req.body.numbers.forEach(element => {
        sum+=element;
    });
   
    res.send("sum: "+sum)
  })

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})